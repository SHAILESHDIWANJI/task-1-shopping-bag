import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { ProductComponent } from './product/product.component';
import { ProductListComponent } from './product/product-list/product-list.component';
import { ProductItemComponent } from './product/product-list/product-item/product-item.component';
import { ShoppingBagComponent } from './shopping-bag/shopping-bag.component';
import { DialogFormComponent } from './header/dialog-form/dialogue-form.component';
import { CustomProductService } from './shared/services/customProduct.service';
import { ShoppingBagService } from './shared/services/shoppingBagProduct.service';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    ProductComponent,
    ProductListComponent,
    ProductItemComponent,
    ShoppingBagComponent,
  DialogFormComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [
    CustomProductService,
    ShoppingBagService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
