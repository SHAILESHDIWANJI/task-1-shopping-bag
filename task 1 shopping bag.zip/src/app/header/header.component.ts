import { Component } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class HeaderComponent {
  dialogBox: boolean = false; 

navigateToForm() {
 this.dialogBox = !this.dialogBox; 
}
removeForm(eve:any){
  this.dialogBox=eve
}
}
