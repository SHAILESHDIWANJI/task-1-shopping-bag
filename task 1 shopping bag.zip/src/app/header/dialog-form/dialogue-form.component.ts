import { Component, EventEmitter, Input, Output, output, ViewChild } from '@angular/core';
import { CustomProductService } from '../../shared/services/customProduct.service';
import { product } from '../../shared/model/customProduct.model';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-dialog-form',
  templateUrl: './dialogue-form.component.html',
  styleUrl: './dialogue-form.component.scss'
})
export class DialogFormComponent   {
  @ViewChild('prodName') prodName:any
  @ViewChild('prodImg') prodImg:any 
  @ViewChild('prodQuantity') prodQuantity:any 
  @ViewChild('prodPrice') prodPrice:any 
  constructor(private customProducts:CustomProductService ){}
  errormsg:any
 createNewProduct(){
  if(!this.prodImg.nativeElement.value ||!this.prodName.nativeElement.value ||!this.prodPrice.nativeElement.value   || !this.prodPrice.nativeElement.value || isNaN(Number(this.prodQuantity.nativeElement.value )) ||isNaN(Number(this.prodPrice.nativeElement.value)) ||this.prodPrice.nativeElement.value<=0 || this.prodQuantity.nativeElement.value<=0 ){
this.errormsg='Please fill the values'
  }else{
    
    let myProduct= new product(this.prodImg.nativeElement.value,this.prodName.nativeElement.value,+this.prodQuantity.nativeElement.value,+this.prodPrice.nativeElement.value)
    this.customProducts.addNewProduct(myProduct)
    this.errormsg=''
    console.log(this.prodImg);
     }
  }
  @Input() formCondition:boolean=false
  @Output() sendFormCondition=new EventEmitter()
  removeForm(){
this.sendFormCondition.emit(!this.formCondition)
console.log(!this.formCondition);
}}
