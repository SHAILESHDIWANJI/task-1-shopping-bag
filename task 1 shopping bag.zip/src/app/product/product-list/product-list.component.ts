import { Component, OnInit } from '@angular/core';
import { CustomProductService } from '../../shared/services/customProduct.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.scss'
})
export class ProductListComponent implements OnInit {
productListfromService:any
constructor(private customProductList:CustomProductService){}
ngOnInit(): void {
  this.productListfromService=this.customProductList.getProductList()
  this.customProductList.productListEmitter.subscribe((data:any)=>{
    this.productListfromService=data
  })
}
}
