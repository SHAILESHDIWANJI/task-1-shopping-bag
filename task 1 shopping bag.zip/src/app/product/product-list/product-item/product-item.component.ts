import { Component, Input, OnInit } from '@angular/core';
import { CustomProductService } from '../../../shared/services/customProduct.service';
import { ShoppingBagService } from '../../../shared/services/shoppingBagProduct.service';

@Component({
  selector: 'app-product-item',
  templateUrl: './product-item.component.html',
  styleUrls: ['./product-item.component.scss'],
})
export class ProductItemComponent implements OnInit {
  @Input() productItems: any;

  constructor(
    private customProductService: CustomProductService,
    private shoppingBagService: ShoppingBagService
  ) {}

  decreaseQuantity(): void {
    if (this.productItems.quantity > 0) {
      this.productItems.quantity--;
      this.customProductService.updateProductQuantity(
        this.productItems.name,
        this.productItems.quantity
      );
    }
  }

  increaseQuantity(): void {
    this.productItems.quantity++;
    this.customProductService.updateProductQuantity(
      this.productItems.name,
      this.productItems.quantity
    );
  }

 addProductToBag(productName: string): void {
  const filteredProduct = this.customProductService
    .getProductList()
    .find((product) => product.name === productName);

  if (filteredProduct) {
    const productCopy = { ...filteredProduct }; // Clone the product to avoid reference issues
    this.shoppingBagService.addProductToShoppingBag(productCopy);
  }
}

  
  

  ngOnInit(): void {}
}
