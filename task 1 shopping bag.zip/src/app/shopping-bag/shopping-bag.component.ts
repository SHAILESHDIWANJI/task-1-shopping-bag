import { Component, OnInit } from '@angular/core';
import { ShoppingBagService } from '../shared/services/shoppingBagProduct.service';

@Component({
  selector: 'app-shopping-bag',
  templateUrl: './shopping-bag.component.html',
  styleUrls: ['./shopping-bag.component.scss'],
})
export class ShoppingBagComponent implements OnInit {
  showProductInBag: any[] = [];
  totalPrice: number = 0;

  constructor(private shoppingBagProduct: ShoppingBagService) {}

  ngOnInit(): void {
    this.showProductInBag = this.shoppingBagProduct.getShoppingBagProduct();

    this.shoppingBagProduct.sendtoBag.subscribe((updatedBag) => {
      this.showProductInBag = updatedBag;
      this.calculateTotalPrice(); 
    });
  }

  removeItem(productName: string): void {
    this.shoppingBagProduct.removeProductFromBag(productName);
  }

  calculateTotalPrice(): void {
    this.totalPrice = this.showProductInBag.reduce(
      (sum, product) => sum + product.quantity * product.price,
      0
    );
  }
}
