import { Injectable, EventEmitter } from '@angular/core';
import { product } from '../model/customProduct.model';

@Injectable({
  providedIn: 'root',
})
export class ShoppingBagService {
  shoppingProductList: product[] = [];
  sendtoBag = new EventEmitter<product[]>();

  getShoppingBagProduct() {
    return this.shoppingProductList.slice();
  }

  addProductToShoppingBag(newProduct: product): void {
    const existingProduct = this.shoppingProductList.find(
      (product) => product.name === newProduct.name
    );

    if (existingProduct) {
      existingProduct.quantity += newProduct.quantity;
    } else {
      this.shoppingProductList.push(newProduct);
    }

    this.sendtoBag.emit([...this.shoppingProductList]);
  }

  removeProductFromBag(productName: string): void {
    const productIndex = this.shoppingProductList.findIndex(
      (product) => product.name === productName
    );

    if (productIndex !== -1) {
      this.shoppingProductList.splice(productIndex, 1);
      this.sendtoBag.emit([...this.shoppingProductList]);
    }
  }
}
