import { Injectable, EventEmitter } from '@angular/core';
import { product } from '../model/customProduct.model';

@Injectable({
  providedIn: 'root',
})
export class CustomProductService {
  productList = [
    new product(
      'https://www.bigbasket.com/media/uploads/p/xl/241600_7-tata-salt-iodized.jpg',
      'Tata Salt',
      1,
      24
    ),
    new product(
      'https://m.media-amazon.com/images/I/61X6qiHlCOL.jpg',
      'Biscuit',
      1,
      45
    ),
  ];

  productListEmitter = new EventEmitter<product[]>();
  productItemEmitter = new EventEmitter<product>();

  getProductList(): product[] {
    return [...this.productList];
  }

  addNewProduct(newProduct: product): void {
    this.productList.push(newProduct);
    this.productListEmitter.emit([...this.productList]); 
  }

  calculateTotal(): number {
    return this.productList.reduce(
      (total, product) => total + product.quantity * product.price,
      0
    );
  }

  updateProductQuantity(productName: string, quantity: number): void {
    const product = this.productList.find((p) => p.name === productName);
    if (product) {
      product.quantity = Math.max(0, quantity); 
      this.productListEmitter.emit([...this.productList]); 
    }
  }

  getSpecificProduct(productName: string): product | undefined {
    return this.productList.find((product) => product.name === productName);
  }
}
