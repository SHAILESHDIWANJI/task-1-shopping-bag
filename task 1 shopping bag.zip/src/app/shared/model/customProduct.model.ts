export class product{
    img:string;
    name:string;
    quantity:number
    price:number;
    constructor(prodImg:string,prodName:string,prodQuantity:number,prodPrice:number){
        this.img=prodImg;
        this.name=prodName;
        this.quantity=prodQuantity
        this.price=prodPrice
    }
}